cel.addEventListener("keyup", function () {
    far.value = Math.round(9/5 * cel.value + 32);
});
far.addEventListener("keyup", function () {
    cel.value = Math.round(5/9 * (far.value - 32));
});
var count = 0;
var allcount = 0;
var result;
var fl;
but.addEventListener("click", function () {
    allcount++;
    if(allcount < 11){
        if(res.value == result && fl != 1)
            count++;
        var first = Math.round(1 + Math.random() * 8.5);
        var second = Math.round(1 + Math.random() * 8.5);
        tasks.innerHTML = first + " * " + second + " = ";
        result = first * second;
        res.value = "";
        textcheck.innerHTML = "";
        corrected.innerHTML = "Will be corrected (" + count + "/10)";
        fl = 0;
    }
});
butcheck.addEventListener("click", function () {
    fl=1;
    if(res.value == result)
       textcheck.innerHTML = "Correct!";
    else {
        textcheck.innerHTML = "Incorrect!(" + result + ")";

    }
});
var result2;
var arr = [];
var randCorrect;
var arrRes = [res1, res2, res3, res4];
var allCount2 = 0;
var count2 = 0;
var fl2 = 0;
var tt = document.getElementsByName("r");
but2.addEventListener("click", function () {
    allCount2++;
    if(allCount2 < 11){
        var first = Math.round(1 + Math.random() * 8.5);
        var second = Math.round(1 + Math.random() * 8.5);
        tasks2.innerHTML = first + " * " + second + " = ";
        result2 = first * second;
        for (var i = 0; i < 4; i++)
            arr[i] = Math.round(1 + Math.random() * 89.5);
        randCorrect = Math.round(0 + Math.random() * 3.5);
        arr[randCorrect] = result2;
        for (var i = 0; i < 4; i++)
            arrRes[i].innerHTML = arr[i];
        corrected2.innerHTML = "Will be corrected (" + count2 + "/10)";
        for (var i = 0; i < tt.length; i++){
            tt[i].disabled = 0;
            tt[i].checked = 0;
        }
        fl2 = 0;
        textcheck2.innerHTML = "";
    }
    console.log(count2)
});
res1.addEventListener("click",function () {
    var tmp = res1.innerText;
    if(tmp == result2 && fl2 != 1)
        count2++;
    for (var i = 0; i < tt.length; i++)
        tt[i].disabled = 1;
    fl2 = 1;
    if(tmp == result2)
        textcheck2.innerHTML = "Correct!";
    else
        textcheck2.innerHTML = "Incorrect!(" + result2 + ")";
});
res2.addEventListener("click",function () {
    var tmp = res2.innerText;
    if(tmp == result2 && fl2 != 1)
        count2++;
    fl2 = 1;
    for (var i = 0; i < tt.length; i++)
        tt[i].disabled = 1;
    if(tmp == result2)
        textcheck2.innerHTML = "Correct!";
    else
        textcheck2.innerHTML = "Incorrect!(" + result2 + ")";
});
res3.addEventListener("click",function () {
    var tmp = res3.innerText;
    if(tmp == result2 && fl2 != 1)
        count2++;
    fl2 = 1;
    for (var i = 0; i < tt.length; i++)
        tt[i].disabled = 1;
    if(tmp == result2)
        textcheck2.innerHTML = "Correct!";
    else
        textcheck2.innerHTML = "Incorrect!(" + result2 + ")";
});
res4.addEventListener("click",function () {
    var tmp = res4.innerText;
    if(tmp == result2 && fl2 != 1)
        count2++;
    fl2 = 1;
    for (var i = 0; i < tt.length; i++)
        tt[i].disabled = 1;
    if(tmp == result2)
        textcheck2.innerHTML = "Correct!";
    else
        textcheck2.innerHTML = "Incorrect!(" + result2 + ")";
});
var imagesArray = [
    {path: '1.jpg', title : 'bomba', description : 'art'},
    {path: '2.jpg', title : 'pyshka', description : 'art'},
    {path: '3.jpg', title : 'petarda', description : 'art'}];
var a1, a2, img;
window.addEventListener("load", function () {
    var tbl = document.createElement("table");
    var tr1 = document.createElement("tr");
    var tr2 = document.createElement("tr");
    var tr3 = document.createElement("tr");
    var td1 = document.createElement("td");
    var td2 = document.createElement("td");
    var td3 = document.createElement("td");
    var td4 = document.createElement("td");
    var td5 = document.createElement("td");
    a1 = document.createElement("a");
    a2 = document.createElement("a");
    var img =document.createElement("img");
    var arrtd = [td1, td2, td3, td4, td5];
    for(i = 0; i < arrtd.length; i++)
        arrtd[i].style.cssText = "padding:10px; \ border: 1px solid black; \ ";
    td1.style.cssText = "width:20%;";
    td3.style.cssText = "width:20%;";
    td2.style.cssText = "height:50px;\ border: 1px solid black";
    td5.style.cssText = "height:100px;\ border: 1px solid black";
    tr1.style.cssText = "padding:10px; \ border: 1px solid black;";
    tr2.style.cssText = "padding:10px; \ border: 1px solid black";
    tr3.style.cssText = "padding:10px; \ border: 1px solid black";
    tbl.style.cssText = "border: 1px solid black; \ width:800px; \ height:500px; \ border-collapse:collapse; \ margin:auto";
    img.style.cssText = "width:800px";
    gallery.appendChild(tbl);
    tbl.appendChild(tr1);
    tr1.appendChild(td1);
    tr1.appendChild(td2);
    tr1.appendChild(td3);
    tbl.appendChild(tr2);
    tr2.appendChild(td4);
    tbl.appendChild(tr3);
    tr3.appendChild(td5);
    td1.appendChild(a1);
    td3.appendChild(a2);
    td4.appendChild(img);
    a2.innerHTML = "right";
    a1.innerHTML = "left";
    img.setAttribute("src", "1.jpg");
    var i = 0;
    a2.onclick = function () {
        if(i == 2){
            a2.style.cssText = "display:none;";
            td3.style.cssText = "padding:17px;";
        }
        else{

            i++;
            img.setAttribute("src", imagesArray[i].path);
        }
    };
    a1.onclick = function () {
        if(i == 0){
            a1.style.cssText = "display:none;";
            td1.style.cssText = "padding:17px;";
        }
        else{
            a1.style.cssText = "display:inline-block;";
            i--;
            img.setAttribute("src", imagesArray[i].path);
        }
    };
    a1.setAttribute("href", "#");
    a2.setAttribute("href", "#");
    td1.setAttribute("rowspan", 3);
    td3.setAttribute("rowspan", 3);
});
function gallerys() {


}


