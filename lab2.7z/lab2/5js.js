function isIPAddress(ip) {
    var regex = /^([0-9]{1,3}\.){3}[0-9]{1,3}$/;
    if(regex.test(ip))
        return true;
    else
        return false;
}

function findRGBA(text) {
    var regex = /rgba\(((([0-1]?[0-9]?[0-9])|([2][0-4][0-9])|(25[0-5])),\s?){3}(0|1|0.\d+)\)/;
    if(text.match(regex))
        return text.match(regex)[0];
    else
        return null;
}

function findHexColor(text) {
    var regex =/#[a-f0-9]{6}\b|#[a-f0-9]{3}\b/i;
    if(text.match(regex))
        return text.match(regex)[0];
    else
        return null;
}

function findTags(text, tag) {
    var regex = new RegExp("<" + tag + ">", "g");
    var rex = text.match(regex);
    if(regex.test(text))
        for(var i = 0; i < rex.length; i++)
                alert(rex[i]);
       // else alert(null);
}

function findPosNum(nums) {
    var regex = /(-?\d+)/g;
    var x =nums.match(regex);
    for(var i = 0; i < nums.match(regex).length; i++)
        if(Math.sign(x[i])== 1)
            alert(x[i]);
}

function findDates(date) {
    var regex =/((19|20)\d{2})-(0\d|1\d)-([012]\d|3[01])/g;
    for(var i = 0; i < date.match(regex).length; i++)
        if(regex.test(date))
            alert(date.match(regex)[0]);
        else alert("null")
}