var date =  new Date();
var dateNum = date.getDate();
var year = date.getFullYear();
var hour = date.getHours();
var minutes = date.getMinutes();
var daysAgo = document.getElementById('daysAgo');
var yeah = document.getElementById('year');
var mon = document.getElementById('month');
var dat = document.getElementById('dates');
function days(sday){
    var arr = ["неділя", "понеділок", "вівторок", "середа", "четвер", "пятниця", "субота"];
    return arr[sday.getDay()];
}
function standartdays(sd){
    var day = sd.getDay();
    if(sd.getDay() == 0)
        day = 7;
    return day;
}
function months(smonth){
    var arr = ['Січень', 'Лютий', 'Березень', 'Квітень','Травень', 'Червень', 'Липень', 'Серпень', 'Вересень', 'Жовтень', 'Листопад', 'Грудень'];
    return arr[smonth.getMonth()];
}
function objday(d){
    var obj = {dayNumber: standartdays(d), dayName: days(d)};
    return obj;
}
function daysago(date, days) {
    date.setDate(date.getDate() - days);
    return date.getDate();
}
function lastday(y, m) {
    var dat = new Date(y, m, 0);
    return dat.getDate();
}
function objtime(d) {
    var tomorrow = new Date(d.getFullYear(), d.getMonth(), d.getDate()+1);
    var obj = {secondsStartDay: d.getHours() * 3600 + d.getMinutes() * 60 + d.getSeconds(), secondsEndDay: Math.round((tomorrow - d)/1000)};
    return obj;
}
function outputdate(d){
    var split = d.split(".");
    var newd = new Date(split[0], split[1], split[2]);
    var dd = newd.getDate();
    var mm = newd.getMonth();
    var yyyy = newd.getFullYear();
    return dd + "." + mm + "." + yyyy;
}
but1.addEventListener("click", function(){
    res1.innerHTML = "Дата: " + dateNum + " " + months(date) + " " + year + " року" + "<br>" + "День тижня: " + days(date) + "<br>" + "Час: " + hour + ":" + minutes;
});
but2.addEventListener("click", function(){
    res2.innerHTML = "Номер дня: " + objday(date).dayNumber + "<br>" + "Назва дня: " + objday(date).dayName;
});
but3.addEventListener("click", function(){
    res3.innerHTML = daysago(date, daysAgo.value) + " " + months(date) + " " + date.getFullYear() + " року";
});
but4.addEventListener("click", function(){
    res4.innerHTML = lastday(yeah.value, mon.value);
});
but5.addEventListener("click", function(){
    res5.innerHTML = objtime(date).secondsStartDay + " " + objtime(date).secondsEndDay;
});
but6.addEventListener("click", function(){
    res6.innerHTML = outputdate(dat.value);
});