function isInteger(num) {
    if(~~num == num) return "true";
    else return "false";
}
function f(a, b) {
    ~~a;
    ~~b;

    if(a > b || a < 0 || b < 0){
        alert("Не вірне введення діапазону!")
    }
    if(a <= 2 && a > 0){
        console.log(2);
    }
    var fl = true;
    for(var i = a; i <= b; i++){
        for(var j = 2; j < i; j++){
            fl = false;
            if(i%j===0){
                fl = true;
                break;
            }
        }
        if(fl!==true){
            console.log(i);
        }
    }
}